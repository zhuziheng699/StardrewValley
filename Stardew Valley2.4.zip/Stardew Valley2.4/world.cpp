#include "world.h"
#include "icon.h"
#include <fstream>
#include <sstream>
#include <iostream>
#include <string>
#include <vector>
#include <QPainter>
using namespace std;
void World::initWorld(string mapFile){
    //读入地图文件，生成地图上的对象
    const char * out=mapFile.c_str();
    ifstream _map(out);
    char ch[100]="";
    string s="";
    RPGObj _obj;
    int i=0;
    if(!_objs.empty()){
        _objs.clear();
    }
    while(!_map.eof())
    {
       _map.getline(ch,100);
       vector<string> res;
       s=ch;
       string result;
           //将字符串读到input中
       stringstream input(s);
       while(input>>result)
            res.push_back(result);

       if(i==0){
           (*_player).setRect(atof(res[1].c_str()),atof(res[2].c_str()),32,32);
           _player->setlife(atoi(res[3].c_str()));
       }else{
           _obj.initObj(res[0]);
           _obj.setPosX(atoi(res[1].c_str()));
           _obj.setPosY(atoi(res[2].c_str()));
           this->_objs.push_back(_obj);
           _obj.setRect(_obj.getPosX(),_obj.getPosY(),_obj.getWidth(),_obj.getWidth());
       }
       i++;
    }
_map.close();


}


void World::show(QPainter * painter){
    vector<RPGObj>::iterator it;
    for(it=this->_objs.begin();it!=this->_objs.end();it++){
        (*it).show(painter);
    }
     if(_player->getlife()>0){
         this->_player->logic();
         this->_player->draw(painter);
     }
     else if(_player->getlife()==0){cout<<"Sorry, you are dead."<<endl<<"GAME OVER"<<endl;//死亡时将小人图片替换成坟墓
         RPGObj _obj;
         _obj.initObj("tomb");
         _obj.setPosX(_player->getBindRect().left());
         _obj.setPosY(_player->getBindRect().top());
         _obj.show(painter);
     }
}
bool World::Player_if_move(QRectF bind){
    vector<RPGObj>::iterator it;
    for(it=this->_objs.begin();it!=this->_objs.end();it++){
        //cout<<"1"<<endl;
        if(bind.intersects((*it).getBindRect())){//判断移动点是否在图形边框内
            if((*it).canDead()){
                _player->setlife(_player->getlife()-1);//死亡点生命值减1
               if(_player->getlife()>=0) cout<<"You have "<<_player->getlife()<<" life."<<endl;
            }
            if((*it).cantalk()){
                this->_words=(*it).talks();
            }
            if(!(*it).canCover())return false;
        }
        if((*it).getBindRect().left()==bind.left()&&(*it).getBindRect().top()==bind.left()){
            if((*it).canEat()){
                (*it).setRect(-1,-1,0,0);
                it=_objs.erase(it);//移除吃掉的物体
                break;
            }
        }
    }
   // cout<<"test"<<endl;
    return true;
}

void World::handlePlayerMove(int direction, int steps){
    _player->setFaceDirection(direction);
    switch (direction){
        case 1:
            _player->startMove(0,-steps);
            break;
        case 2:
            _player->startMove(0,steps);
            break;
        case 3:
            _player->startMove(-steps,0);
            break;
        case 4:
            _player->startMove(steps,0);
            break;
    }
    if(!Player_if_move(_player->getBindRect())){
        _player->startMove(0,0);
    }
}
void World::save_game(string save_file_name){
    string out="c:/Qt/map/Save&Load/"+save_file_name+".txt";
    const char * path=out.c_str();
    ofstream save(path);
    save<<"player"<<" "<<_player->getBindRect().left()<<" "<<_player->getBindRect().top()<<" "<<_player->getlife();
    vector<RPGObj>::iterator it;
    for(it=this->_objs.begin();it!=this->_objs.end();it++){
        save<<endl<<(*it).getObjType()<<" "<<(*it).getBindRect().left()<<" "<<(*it).getBindRect().top();
    }
    save_name(save_file_name);
}
void World::save_name(string save_file_name){
    string out="c:/Qt/map/Save&Load/save_name.txt";
    const char * path=out.c_str();
    ofstream savename(path,ios::app);
    savename<<save_file_name<<endl;
}
bool World::if_collapse(QRectF a, QRectF b){
    if(a.intersects(b))return true;
    return false;
}
