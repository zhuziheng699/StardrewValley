#ifndef PLAYER_H
#define PLAYER_H
#include "rpgobj.h"
#include <vector>
#include <string>
#include "moveobjs.h"
#include "icon.h"

class Player: public Moveobjs
{
private:
    int faceDirection;
    int paceCount;
    int onePaceCount;
    int life;
    bool isMoving;
    qreal speedX;
    qreal speedY;
    //int blood;
    Moveobjs* enemyAttack;
    Moveobjs* enemySkill;
public:
    Player(Moveobjs*,Moveobjs*);
    void draw(QPainter*);
    void logic();
    void setFaceDirection(int);
    int getFaceDirection();
    void startMove(qreal = 0,qreal = 0);
    void endMove();
    void move();
    void attack();
    void skill();
    void setlife(int a){life=a;}
    int getlife(){return life;}
    //void attackSignal(Player*);
    //void skillSignal(Player*);
    //void attacked(int);
    //void skilled(int);
};

#endif // PLAYER_H
