#include "mw1.h"
#include "ui_mw1.h"
#include "icon.h"
#include <string>
#include <map>
#include <iostream>
#include <QTimer>
#include <ctime>
using namespace std;

MW1::MW1(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MW1)
{
    ui->setupUi(this);

    timer = new QTimer(this);
    connect(timer,SIGNAL(timeout()),this,SLOT(movingmonster()));
    timer->start(500);//怪兽移动

    startButton = new QPushButton(this);
    startButton->setGeometry(250,100,200,200);
    startButton->setStyleSheet("QPushButton{border-image:url(/Users/walden/Programme/Qt/Stardew Valley2.2/Images/startbutton.jpg)}""QPushButton:pressed{margin:2px 2px 2px 2px}");
    QObject::connect(startButton,SIGNAL(clicked()),this,SLOT(start()));
    SaveButton = new QPushButton(this);
    SaveButton->setGeometry(250,310,200,200);
    SaveButton->setStyleSheet("QPushButton{border-image:url(/Users/walden/Programme/Qt/Stardew Valley2.2/Images/savebutton.jpg)}""QPushButton:pressed{margin:2px 2px 2px 2px}");
    QObject::connect(SaveButton,SIGNAL(clicked()),this,SLOT(save()));
    LoadButton = new QPushButton(this);
    LoadButton->setGeometry(250,520,200,200);
    LoadButton->setStyleSheet("QPushButton{border-image:url(/Users/walden/Programme/Qt/Stardew Valley2.2/Images/loadbutton.jpg)}""QPushButton:pressed{margin:2px 2px 2px 2px}");
    QObject::connect(LoadButton,SIGNAL(clicked()),this,SLOT(load()));
    ContinueButton = new QPushButton(this);
    ContinueButton->setGeometry(250,100,200,200);
    ContinueButton->setStyleSheet("QPushButton{border-image:url(/Users/walden/Programme/Qt/Stardew Valley2.2/Images/continuebutton.jpg)}""QPushButton:pressed{margin:2px 2px 2px 2px}");
    QObject::connect(ContinueButton,SIGNAL(clicked()),this,SLOT(Continue()));
    ContinueButton->setVisible(false);
    //init game world
    _game.initWorld("/Users/walden/Programme/Qt/Stardew Valley2.2/map.txt");//TODO 应该是输入有效的地图文件
}

MW1::~MW1()
{
    delete ui;
}

void MW1::paintEvent(QPaintEvent *e){
    QPainter *pa;
    pa = new QPainter();
    pa->begin(this);
    this->_game.show(pa);
    pa->end();
    delete pa;
    if(_game.getwords()!="0"){
        QPainter painter(this);
        //设置一个矩形
        QRectF rect((_game.getplayer().getPosX()+1)*32, _game.getplayer().getPosY()*32, 300, 50);

        //为了更直观地看到字体的位置，我们绘制出这个矩形
        painter.fillRect(rect,QBrush(QColor(0,85,255)));
        //我们这里先让字体水平居中
        QFont font("宋体", 10, QFont::Bold, true);
        //设置下划线
        font.setUnderline(true);
        //设置上划线
        font.setOverline(true);
        //设置字母大小写
        font.setCapitalization(QFont::SmallCaps);
        //设置字符间的间距
        font.setLetterSpacing(QFont::AbsoluteSpacing, 5);
        //使用字体
        painter.setFont(font);
        painter.setPen(Qt::white);
        painter.drawText(rect, Qt::AlignHCenter, QString::fromStdString(_game.getwords()));
        painter.translate(50, 50);
        _game.setwords("0");
        //painter.rotate(90);
        //painter.drawText(0, 0, tr("helloqt"));
    }
    if(issaved==1){

        QPainter painter(this);
        QRectF source(0,0,719,568);
        QRectF target(100,100,600,500);
        QImage back("C:/Qt/map/Images/save_back.jpg");
        painter.drawImage(target,back,source);
        _game.save_game("test");
        isSaved(0);
    }

}

void MW1::keyPressEvent(QKeyEvent *e)
{
    //direction = 1,2,3,4 for 上下左右
    if(_game.getplayer().getlife()>0&&!startButton->isVisible()&&issaved==0){

    if(e->key() == Qt::Key_A)
    {
        this->_game.handlePlayerMove(3,1);
    }
    else if(e->key() == Qt::Key_D)
    {
        this->_game.handlePlayerMove(4,1);
    }
    else if(e->key() == Qt::Key_W)
    {
        this->_game.handlePlayerMove(1,1);
    }
    else if(e->key() == Qt::Key_S)
    {
         this->_game.handlePlayerMove(2,1);
    }else if(e->key()==Qt::Key_Escape){
        startButton->setVisible(true);
        LoadButton->setVisible(true);
        SaveButton->setVisible(true);
    }
    this->repaint();
    }
    if(_game.getplayer().getlife()==0){
        ContinueButton->setVisible(true);
        LoadButton->setVisible(true);
        SaveButton->setVisible(true);
    }
}

void MW1::on_pushButton_clicked()
{
    _game.reset_player(3);
    //_game.getplayer().setPosX(15);
   // _game.getplayer().setPosY(15);
    this->repaint();
}
void MW1::start(){
    startButton->setVisible(false);
    LoadButton->setVisible(false);
    SaveButton->setVisible(false);
    ContinueButton->setVisible(false);
}
void MW1::load(){
    string load="/Users/walden/Programme/Qt/Stardew Valley2.2/map/Save&Load/test.txt";
    _game.initWorld(load);
    this->repaint();
    startButton->setVisible(false);
    LoadButton->setVisible(false);
    SaveButton->setVisible(false);
    ContinueButton->setVisible(false);
}
void MW1::save(){
    isSaved(1);
    this->update();
    startButton->setVisible(false);
    LoadButton->setVisible(false);
    SaveButton->setVisible(false);
    ContinueButton->setVisible(false);

}
void MW1::Continue(){
    _game.reset_player(3);
    this->repaint();
    startButton->setVisible(false);
    LoadButton->setVisible(false);
    SaveButton->setVisible(false);
    ContinueButton->setVisible(false);
}
void MW1::movingmonster(){
    qsrand(QTime(0,0,0).secsTo(QTime::currentTime()));
    int i=rand() % 60;
    if(i<15){
        _game.handleMonsterMove(1,1);
    }
    if(i>=15&&i<30){
        _game.handleMonsterMove(2,1);
    }
    if(i>=30&&i<45){
        _game.handleMonsterMove(3,1);
    }
    if(i>45){
        _game.handleMonsterMove(4,1);
    }
}
