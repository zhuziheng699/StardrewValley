#ifndef MW1_H
#define MW1_H

#include <QMainWindow>
#include <QImage>
#include <QPainter>
#include <QPushButton>
#include<QKeyEvent>
#include "rpgobj.h"
#include "world.h"
#include "player.h"
#include <QTimer>
#include <QTime>

namespace Ui {
class MW1;
}

class MW1 : public QMainWindow
{
    Q_OBJECT

public:
    QPushButton* startButton;
    QPushButton* SaveButton;
    QPushButton* LoadButton;
    QPushButton* ContinueButton;
    explicit MW1(QWidget *parent = 0);
    ~MW1();
    void paintEvent(QPaintEvent *e);
    void keyPressEvent(QKeyEvent *);
    void isSaved(int a){issaved=a;}
private slots:
    void on_pushButton_clicked();
    void movingmonster();
    
private:
    Ui::MW1 *ui;
    World _game;
    int issaved=0;
    QTimer *timer;
public slots:
    void start();
    void save();
    void load();
    void Continue();
};

#endif // MW1_H
