#ifndef PLAYER_H
#define PLAYER_H
#include "rpgobj.h"
#include <vector>
#include <string>
#include "icon.h"
class Player: public RPGObj
{
public:
    Player(){}
    ~Player(){}
    bool move(int direction, int steps=1);
        //direction =1,2,3,4 for 上下左右
    int getlife(){return this->life;}
    void setlife(int a){this->life=a;}
private:
    int life;//生命值=3
};

#endif // PLAYER_H
