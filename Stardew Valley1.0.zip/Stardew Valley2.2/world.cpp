#include "world.h"
#include "icon.h"
#include <fstream>
#include <sstream>
#include <iostream>
#include <string>
#include <vector>
#include <QPainter>
using namespace std;
void World::initWorld(string mapFile){
    //读入地图文件，生成地图上的对象
    const char * out=mapFile.c_str();
    ifstream _map(out);
    char ch[100]="";
    string s="";
    RPGObj _obj;
    int i=0;
    if(!_objs.empty()){
        _objs.clear();
    }
    while(!_map.eof())
    {
       _map.getline(ch,100);
       vector<string> res;
       s=ch;
       string result;
           //将字符串读到input中
       stringstream input(s);
       while(input>>result)
            res.push_back(result);
       _obj.initObj(res[0]);
       _obj.setPosX(atoi(res[1].c_str()));
       _obj.setPosY(atoi(res[2].c_str()));
       if(i==0){
           _player.initObj("player");
           _player.setPosX(_obj.getPosX());
           _player.setPosY(_obj.getPosY());
           _player.setlife(atoi(res[3].c_str()));
       }else{
           this->_objs.push_back(_obj);
       }
       i++;
    }
    _map.close();

    this->_monster.initObj("player");
    this->_monster.setPosX(8);
    this->_monster.setPosY(11);
}


void World::show(QPainter * painter){
    vector<RPGObj>::iterator it;
    for(it=this->_objs.begin();it!=this->_objs.end();it++){
        (*it).show(painter);
    }
     if(_player.getlife()>0)this->_player.show(painter);
     else if(_player.getlife()==0){cout<<"Sorry, you are dead."<<endl<<"GAME OVER"<<endl;//死亡时将小人图片替换成坟墓
         RPGObj _obj;
         _obj.initObj("tomb");
         _obj.setPosX(_player.getPosX());
         _obj.setPosY(_player.getPosY());
         _obj.show(painter);
     }

     this->_monster.show(painter);
}
bool World::Player_if_move(int posx, int posy){
    vector<RPGObj>::iterator it;
    for(it=this->_objs.begin();it!=this->_objs.end();it++){
        //cout<<"1"<<endl;
        if(((*it).getPosX()<=posx&&(*it).getPosX()+(*it).getWidth()>posx)&&
                ((*it).getPosY()<=posy&&(*it).getPosY()+(*it).getHeight()>posy)){//判断移动点是否在图形边框内
            if((*it).canDead()){
                _player.setlife(_player.getlife()-1);//死亡点生命值减1
               if(_player.getlife()>=0) cout<<"You have "<<_player.getlife()<<" life."<<endl;
            }
            if((*it).cantalk()){
                this->_words=(*it).talks();
            }
            if(!(*it).canCover())return false;
        }
        if((*it).getPosX()==posx&&(*it).getPosY()==posy){
            if((*it).canEat()){
                it=_objs.erase(it);//移除吃掉的物体
                break;
            }
        }
    }
   // cout<<"test"<<endl;
    return true;
}

bool World::handlePlayerMove(int direction, int steps){
    switch (direction){
        case 1:
            if(!Player_if_move(_player.getPosX(),_player.getPosY()))return false;
            _player.move(direction,steps);
            return true;
            break;
        case 2:
            if(!Player_if_move(_player.getPosX(),_player.getPosY()+2))return false;
            _player.move(direction,steps);
            return true;
        case 3:
            if(!Player_if_move(_player.getPosX()-1,_player.getPosY()+1))return false;
             _player.move(direction,steps);
            return true;
        case 4:
            if(!Player_if_move(_player.getPosX()+1,_player.getPosY()+1))return false;
             _player.move(direction,steps);
            return true;
    }
}
void World::save_game(string save_file_name){
    string out="c:/Qt/map/Save&Load/"+save_file_name+".txt";
    const char * path=out.c_str();
    ofstream save(path);
    save<<_player.getObjType()<<" "<<_player.getPosX()<<" "<<_player.getPosY()<<" "<<_player.getlife();
    vector<RPGObj>::iterator it;
    for(it=this->_objs.begin();it!=this->_objs.end();it++){
        save<<endl<<(*it).getObjType()<<" "<<(*it).getPosX()<<" "<<(*it).getPosY();
    }
    save_name(save_file_name);
}
void World::save_name(string save_file_name){
    string out="/Users/walden/Programme/Qt/Stardew Valley2.2/map/Save&Load/save_name.txt";
    const char * path=out.c_str();
    ofstream savename(path);
    savename<<save_file_name<<endl;
}
void World::handleMonsterMove(int direction, int steps){
    this->_monster.move(direction, steps);
}
