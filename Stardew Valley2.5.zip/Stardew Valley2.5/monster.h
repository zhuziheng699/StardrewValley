#ifndef MONSTER_H
#define MONSTER_H
#include "moveobjs.h"
#include <vector>
#include <string>
#include "icon.h"
#include "player.h"

class Monster:public Player
{
public:
    Monster();
    ~Monster(){}
};

#endif // MONSTER_H
