#include "world.h"
#include "icon.h"
#include <fstream>
#include <sstream>
#include <iostream>
#include <string>
#include <vector>
#include <QPainter>
using namespace std;
void World::initWorld(string mapFile){
    //读入地图文件，生成地图上的对象
    const char * out=mapFile.c_str();
    ifstream _map(out);

    RPGObj _obj;
    int i=0;
    if(!_objs.empty()){
        _objs.clear();
    }
    while(!_map.eof())
    {
        char ch[100]="";
       _map.getline(ch,100);
       vector<string> res;
       string s="";
       s=ch;
       string result;
           //将字符串读到input中
       stringstream input(s);
       while(input>>result)
            res.push_back(result);

       if(i==0){
           _player.setRect(atof(res[1].c_str()),atof(res[2].c_str()),67,105);
           _player.setlife(atoi(res[3].c_str()));
       }else{
           _obj.initObj(res[0]);
           _obj.setPosX(atoi(res[1].c_str()));
           _obj.setPosY(atoi(res[2].c_str()));
           _obj.setRect(_obj.getPosX(),_obj.getPosY(),_obj.getWidth(),_obj.getHeight());
           this->_objs.push_back(_obj);
       }
       i++;
    }
_map.close();


}


void World::show(QPainter * painter){
    vector<RPGObj>::iterator it;
    for(it=this->_objs.begin();it!=this->_objs.end();it++){
        (*it).show(painter);
    }
     if(_player.getlife()>0){
         this->_player.logic();
         this->_player.draw(painter);
     }

     else if(_player.getlife()<=0){cout<<"Sorry, you are dead."<<endl<<"GAME OVER"<<endl;//死亡时将小人图片替换成坟墓
         RPGObj _obj;
         _obj.initObj("tomb");
         _obj.setPosX(_player.getBindRect().left()/32);
         _obj.setPosY(_player.getBindRect().top()/32);
         _obj.show(painter);
     }
     _monster.logic();
     _monster.draw(painter);
}
int World::Player_if_move(QRectF bind){
    vector<RPGObj>::iterator it;
    for(it=this->_objs.begin();it!=this->_objs.end();it++){
        //cout<<"1"<<endl;
        if(bind.intersects((*it).getBindRect())){//判断移动点是否在图形边框内
            if((*it).canDead()){
                _player.setlife(_player.getlife()-1);//死亡点生命值减1
               if(_player.getlife()>=0)
                   cout<<"You have "<<_player.getlife()<<" life."<<endl;
            }
            if((*it).cantalk()){
                this->_words=(*it).talks();
                return 3;
            }
            if(!(*it).canCover())return 0;
            if((*it).canBang())return 2;
            if((*it).canEat()){
                //(*it).setRect(-1,-1,0,0);
                it=_objs.erase(it);//移除吃掉的物体
                break;
            }
        }
    }
   // cout<<"test"<<endl;
    return 1;
}

void World::handlePlayerMove(int direction, int steps){
    _player.setFaceDirection(direction);
    switch (direction){
        case 1:
        /*if(!Player_if_move(_player.getBindRect().translated(0,-steps))){
            return;
        }*/
            _player.startMove(0,-steps);
            break;
        case 2:
        /*if(!Player_if_move(_player.getBindRect().translated(0,steps))){
            return;
        }*/
            _player.startMove(0,steps);
            break;
        case 3:
        /*if(!Player_if_move(_player.getBindRect().translated(-steps,0))){
            return;
        }*/
            _player.startMove(-steps,0);
            break;
        case 4:
        /*if(!Player_if_move(_player.getBindRect().translated(steps,0))){
            return;
        }*/
            _player.startMove(steps,0);
            break;
    }

}
void World::save_game(string save_file_name){
    string out="c:/Qt/map/Save&Load/"+save_file_name+".txt";
    const char * path=out.c_str();
    ofstream save(path);
    save<<"player"<<" "<<_player.getBindRect().left()<<" "<<_player.getBindRect().top()<<" "<<_player.getlife();
    vector<RPGObj>::iterator it;
    for(it=this->_objs.begin();it!=this->_objs.end();it++){
        save<<endl<<(*it).getObjType()<<" "<<(*it).getBindRect().left()<<" "<<(*it).getBindRect().top();
    }
    save_name(save_file_name);
}
void World::save_name(string save_file_name){
    string out="/Users/walden/Programme/Qt/Stardew Valley2.5/save_name.txt";
    const char * path=out.c_str();
    ofstream savename(path,ios::app);
    savename<<save_file_name<<endl;
}
bool World::if_collapse(QRectF a, QRectF b){
    if(a.intersects(b))return true;
    return false;
}
void World::handleMonsterMove(int direction, int steps){
    _monster.setFaceDirection(direction);
    switch (direction){
        case 1:
            _monster.startMove(0,-steps);
            break;
        case 2:
            _monster.startMove(0,steps);
            break;
        case 3:
            _monster.startMove(-steps,0);
            break;
        case 4:
            _monster.startMove(steps,0);
            break;
    }
}
