#ifndef MOVEOBJS_H
#define MOVEOBJS_H
#include<QObject>
#include<QPainter>
#include<QRectF>
#include<QPixmap>
#include<QVector>

class Moveobjs
{

public:
    Moveobjs();
    ~Moveobjs(){}
    void setRect(QRectF);
    void setRect(qreal,qreal,qreal,qreal);
    QRectF& getBindRect();
    void addFrame(QPixmap);
    void clearAllFrame();
protected:
    QRectF bindRect;
    int frameCount;
    QVector<QPixmap> pixmapListUp;
    QVector<QPixmap> pixmapListDown;
    QVector<QPixmap> pixmapListLeft;
    QVector<QPixmap> pixmapListRight;
    //int pixmapListDirection;
};

#endif // MOVEOBJS_H
