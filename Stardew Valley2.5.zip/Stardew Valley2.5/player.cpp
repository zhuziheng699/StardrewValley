#include "player.h"
#include <fstream>
#include <sstream>
#include <iostream>
#include <vector>
#include <string>
#include "moveobjs.h"
using namespace std;
//direction =1,2,3,4 for 上下左右
Player::Player()
{

    this->addFrame(QPixmap("/Users/walden/Programme/Qt/Stardew Valley2.5/Images/heromove/image 119.png"));
    this->addFrame(QPixmap("/Users/walden/Programme/Qt/Stardew Valley2.5/Images/heromove/image 121.png"));
    this->addFrame(QPixmap("/Users/walden/Programme/Qt/Stardew Valley2.5/Images/heromove/image 123.png"));
    this->addFrame(QPixmap("/Users/walden/Programme/Qt/Stardew Valley2.5/Images/heromove/image 125.png"));
    this->addFrame(QPixmap("/Users/walden/Programme/Qt/Stardew Valley2.5/Images/heromove/image 127.png"));
    this->addFrame(QPixmap("/Users/walden/Programme/Qt/Stardew Valley2.5/Images/heromove/image 129.png"));
    this->addFrame(QPixmap("/Users/walden/Programme/Qt/Stardew Valley2.5/Images/heromove/image 71.png"));
    this->addFrame(QPixmap("/Users/walden/Programme/Qt/Stardew Valley2.5/Images/heromove/image 73.png"));
    this->addFrame(QPixmap("/Users/walden/Programme/Qt/Stardew Valley2.5/Images/heromove/image 75.png"));
    this->addFrame(QPixmap("/Users/walden/Programme/Qt/Stardew Valley2.5/Images/heromove/image 77.png"));
    this->addFrame(QPixmap("/Users/walden/Programme/Qt/Stardew Valley2.5/Images/heromove/image 79.png"));
    this->addFrame(QPixmap("/Users/walden/Programme/Qt/Stardew Valley2.5/Images/heromove/image 81.png"));
    this->addFrame(QPixmap("/Users/walden/Programme/Qt/Stardew Valley2.5/Images/heromove/image 95.png"));
    this->addFrame(QPixmap("/Users/walden/Programme/Qt/Stardew Valley2.5/Images/heromove/image 97.png"));
    this->addFrame(QPixmap("/Users/walden/Programme/Qt/Stardew Valley2.5/Images/heromove/image 99.png"));
    this->addFrame(QPixmap("/Users/walden/Programme/Qt/Stardew Valley2.5/Images/heromove/image 101.png"));
    this->addFrame(QPixmap("/Users/walden/Programme/Qt/Stardew Valley2.5/Images/heromove/image 103.png"));
    this->addFrame(QPixmap("/Users/walden/Programme/Qt/Stardew Valley2.5/Images/heromove/image 105.png"));
    this->addFrame(QPixmap("/Users/walden/Programme/Qt/Stardew Valley2.5/Images/heromove/image 200.png"));
    this->addFrame(QPixmap("/Users/walden/Programme/Qt/Stardew Valley2.5/Images/heromove/image 201.png"));
    this->addFrame(QPixmap("/Users/walden/Programme/Qt/Stardew Valley2.5/Images/heromove/image 202.png"));
    this->addFrame(QPixmap("/Users/walden/Programme/Qt/Stardew Valley2.5/Images/heromove/image 203.png"));
    this->addFrame(QPixmap("/Users/walden/Programme/Qt/Stardew Valley2.5/Images/heromove/image 204.png"));
    this->addFrame(QPixmap("/Users/walden/Programme/Qt/Stardew Valley2.5/Images/heromove/image 205.png"));
    faceDirection = 0;
    paceCount = 0;
    onePaceCount = 0;
    isMoving = false;
    speedX = 0;
    speedY = 0;
    //blood = 100;
}

void Player::setFaceDirection(int fd)
{

    faceDirection = fd;
}

int Player::getFaceDirection()
{
    return faceDirection;
}

void Player::startMove(qreal dx,qreal dy)
{
    isMoving = true;
    speedX = dx;
    speedY = dy;
}

void Player::endMove()
{
    isMoving = false;
    speedX = 0;
    speedY = 0;
}

void Player::move()
{
    bindRect.translate(speedX,0);
    bindRect.translate(0,speedY);
    //static int cnt = 0;
    if(onePaceCount == 6)
    {
        onePaceCount = 0;
        paceCount++;
    }
    onePaceCount++;
}

/*void Player::attack()
{
    emit attackSignal(this);
}

void Player::skill()
{
    emit skillSignal(this);
}*/

void Player::draw(QPainter* painter)
{
    painter->save();
    //static int cnt = 0;
    paceCount = (paceCount == 6?0:paceCount);
    switch(faceDirection)
    {
    case 1:painter->drawPixmap(bindRect.topLeft(),pixmapListUp[paceCount]);break;
    case 2:painter->drawPixmap(bindRect.topLeft(),pixmapListDown[paceCount]);break;
    case 3:painter->drawPixmap(bindRect.topLeft(),pixmapListLeft[paceCount]);break;
    case 4:painter->drawPixmap(bindRect.topLeft(),pixmapListRight[paceCount]);break;
    default:break;
    }
    painter->drawRect(this->bindRect);
    painter->restore();
}

void Player::logic()
{

    if(isMoving)
        move();
    /*if(bindRect.intersects(enemyAttack->getBindRect()))
        emit attacked(3);
    if(bindRect.intersects(enemySkill->getBindRect()))
        emit skilled(8);*/
}
