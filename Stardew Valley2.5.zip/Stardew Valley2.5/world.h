#ifndef WORLD_H
#define WORLD_H
#include "rpgobj.h"
#include <vector>
#include <string>
#include <QPainter>
#include "player.h"
#include "moveobjs.h"
#include "monster.h"
class World
{
public:
    World(){}
    ~World(){}
    void initWorld(string mapFile);
        //输入的文件中定义了初始状态下游戏世界有哪些对象，出生点在哪
        /*e.g.
           player 5 5
           stone 3 3
           fruit 7 8
         */
    void show(QPainter * painter);
        //显示游戏世界所有对象
    void handlePlayerMove(int direction, int steps);
     void handleMonsterMove(int direction, int steps);
        //假定只有一个玩家
    int Player_if_move(QRectF);//判断是否可以覆盖次移动点
    Player getplayer(){return _player;}
    void reset_player(int a){_player.setlife(a);}
    string getwords(){return this->_words;}
    void setwords(string word){_words=word;}
    void save_game(string save_file_name);
    void save_name(string save_file_name);
    bool if_collapse(QRectF,QRectF);
    void player_end_move(){_player.endMove();}
    QRectF playertrans(int a,int b){return _player.trans(a,b);}
    void playertransed(int a ,int b){_player.transed(a,b);}
private:
    vector<RPGObj> _objs;
    vector<Moveobjs*> _mobjs;
    Moveobjs sword;
    Moveobjs fire;
    Player _player;
    Monster _monster;
    string _words="0";
};

#endif // WORLD_H
