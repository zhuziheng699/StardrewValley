#include "monster.h"

Monster::Monster(){
    this->addFrame(QPixmap("/Users/walden/Programme/Qt/Stardew Valley2.5/Images/heromove/image 119.png"));
    this->addFrame(QPixmap("/Users/walden/Programme/Qt/Stardew Valley2.5/Images/heromove/image 121.png"));
    this->addFrame(QPixmap("/Users/walden/Programme/Qt/Stardew Valley2.5/Images/heromove/image 123.png"));
    this->addFrame(QPixmap("/Users/walden/Programme/Qt/Stardew Valley2.5/Images/heromove/image 125.png"));
    this->addFrame(QPixmap("/Users/walden/Programme/Qt/Stardew Valley2.5/Images/heromove/image 127.png"));
    this->addFrame(QPixmap("/Users/walden/Programme/Qt/Stardew Valley2.5/Images/heromove/image 129.png"));
    this->addFrame(QPixmap("/Users/walden/Programme/Qt/Stardew Valley2.5/Images/heromove/image 71.png"));
    this->addFrame(QPixmap("/Users/walden/Programme/Qt/Stardew Valley2.5/Images/heromove/image 73.png"));
    this->addFrame(QPixmap("/Users/walden/Programme/Qt/Stardew Valley2.5/Images/heromove/image 75.png"));
    this->addFrame(QPixmap("/Users/walden/Programme/Qt/Stardew Valley2.5/Images/heromove/image 77.png"));
    this->addFrame(QPixmap("/Users/walden/Programme/Qt/Stardew Valley2.5/Images/heromove/image 79.png"));
    this->addFrame(QPixmap("/Users/walden/Programme/Qt/Stardew Valley2.5/Images/heromove/image 81.png"));
    this->addFrame(QPixmap("/Users/walden/Programme/Qt/Stardew Valley2.5/Images/heromove/image 95.png"));
    this->addFrame(QPixmap("/Users/walden/Programme/Qt/Stardew Valley2.5/Images/heromove/image 97.png"));
    this->addFrame(QPixmap("/Users/walden/Programme/Qt/Stardew Valley2.5/Images/heromove/image 99.png"));
    this->addFrame(QPixmap("/Users/walden/Programme/Qt/Stardew Valley2.5/Images/heromove/image 101.png"));
    this->addFrame(QPixmap("/Users/walden/Programme/Qt/Stardew Valley2.5/Images/heromove/image 103.png"));
    this->addFrame(QPixmap("/Users/walden/Programme/Qt/Stardew Valley2.5/Images/heromove/image 105.png"));
    this->addFrame(QPixmap("/Users/walden/Programme/Qt/Stardew Valley2.5/Images/heromove/image 200.png"));
    this->addFrame(QPixmap("/Users/walden/Programme/Qt/Stardew Valley2.5/Images/heromove/image 201.png"));
    this->addFrame(QPixmap("/Users/walden/Programme/Qt/Stardew Valley2.5/Images/heromove/image 202.png"));
    this->addFrame(QPixmap("/Users/walden/Programme/Qt/Stardew Valley2.5/Images/heromove/image 203.png"));
    this->addFrame(QPixmap("/Users/walden/Programme/Qt/Stardew Valley2.5/Images/heromove/image 204.png"));
    this->addFrame(QPixmap("/Users/walden/Programme/Qt/Stardew Valley2.5/Images/heromove/image 205.png"));
    faceDirection = 0;
    paceCount = 0;
    onePaceCount = 0;
    isMoving = true;
    speedX = 0;
    speedY = 0;

}
