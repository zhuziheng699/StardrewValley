#ifndef MW1_H
#define MW1_H

#include <QMainWindow>
#include <QImage>
#include <QPainter>
#include <QPushButton>
#include<QKeyEvent>
#include "rpgobj.h"
#include "world.h"
#include "player.h"
#include <QLineEdit>
#include <QTimer>
namespace Ui {
class MW1;
}
struct load_name{
    string n="0";
};
class MW1 : public QMainWindow
{
    Q_OBJECT

public:
    QPushButton* startButton;
    QPushButton* SaveButton;
    QPushButton* LoadButton;
    QPushButton* ContinueButton;
    QPushButton* Confirm_save;
    QPushButton* Loadname[8];
    explicit MW1(QWidget *parent = 0);
    ~MW1();
    void paintEvent(QPaintEvent *e);
    void keyPressEvent(QKeyEvent *);
    void isSaved(int a){issaved=a;}
    void isLoaded(int a){isloaded=a;}
private:
    Ui::MW1 *ui;
    World* _game;
    int issaved=0;
    int isloaded=0;
    load_name l[8];
    QLineEdit*savename;
    Player* _hero;
    QTimer move;

public slots:
    void start();
    void save();
    void load();
    void Continue();
    void load_file1(){string path="c:/Qt/map/Save&Load/"+l[0].n+".txt";_game->initWorld(path);isSaved(0);this->update();for(int i=0;i<8;i++){
            Loadname[i]->setVisible(false);
        }}
    void load_file2(){string path="c:/Qt/map/Save&Load/"+l[1].n+".txt";_game->initWorld(path);isSaved(0);this->update();for(int i=0;i<8;i++){
            Loadname[i]->setVisible(false);
        }}
    void load_file3(){string path="c:/Qt/map/Save&Load/"+l[2].n+".txt";_game->initWorld(path);isSaved(0);this->update();for(int i=0;i<8;i++){
            Loadname[i]->setVisible(false);
        }}
    void load_file4(){string path="c:/Qt/map/Save&Load/"+l[3].n+".txt";_game->initWorld(path);isSaved(0);this->update();for(int i=0;i<8;i++){
            Loadname[i]->setVisible(false);
        }}
    void load_file5(){string path="c:/Qt/map/Save&Load/"+l[4].n+".txt";_game->initWorld(path);isSaved(0);this->update();for(int i=0;i<8;i++){
            Loadname[i]->setVisible(false);
        }}
    void load_file6(){string path="c:/Qt/map/Save&Load/"+l[5].n+".txt";_game->initWorld(path);isSaved(0);this->update();for(int i=0;i<8;i++){
            Loadname[i]->setVisible(false);
        }}
    void load_file7(){string path="c:/Qt/map/Save&Load/"+l[6].n+".txt";_game->initWorld(path);isSaved(0);this->update();for(int i=0;i<8;i++){
            Loadname[i]->setVisible(false);
        }}
    void load_file8(){string path="c:/Qt/map/Save&Load/"+l[7].n+".txt";_game->initWorld(path);isSaved(0);this->update();for(int i=0;i<8;i++){
            Loadname[i]->setVisible(false);
        }}
    string confirm();
};

#endif // MW1_H
