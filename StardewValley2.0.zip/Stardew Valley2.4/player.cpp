#include "player.h"
#include <fstream>
#include <sstream>
#include <iostream>
#include <vector>
#include <string>
#include "moveobjs.h"
using namespace std;
//direction =1,2,3,4 for 上下左右
Player::Player(Moveobjs* eA,Moveobjs* eS)
{
    QPixmap hero;
    hero.load("c:/Qt/map/Images/Actor1.png");
    this->addFrame(hero.copy(0,0,32,32));
    this->addFrame(hero.copy(32,0,32,32));
    this->addFrame(hero.copy(64,0,32,32));
    this->addFrame(hero.copy(32,0,32,32));
    this->addFrame(hero.copy(0,32,32,32));
    this->addFrame(hero.copy(32,32,32,32));
    this->addFrame(hero.copy(64,32,32,32));
    this->addFrame(hero.copy(32,32,32,32));
    this->addFrame(hero.copy(32,32,32,32));
    this->addFrame(hero.copy(0,0,64,32));
    this->addFrame(hero.copy(32,0,64,32));
    this->addFrame(hero.copy(64,0,64,32));
    this->addFrame(hero.copy(32,0,64,32));
    this->addFrame(hero.copy(0,32,96,32));
    this->addFrame(hero.copy(32,32,96,32));
    this->addFrame(hero.copy(64,32,96,32));
    this->addFrame(hero.copy(32,32,96,32));
    this->addFrame(hero.copy(32,32,96,32));
    enemyAttack = eA;
    enemySkill = eS;
    faceDirection = 0;
    paceCount = 0;
    onePaceCount = 0;
    isMoving = false;
    speedX = 0;
    speedY = 0;
    //blood = 100;
}

void Player::setFaceDirection(int fd)
{
    if(!enabled)
        return;
    faceDirection = fd;
}

int Player::getFaceDirection()
{
    return faceDirection;
}

void Player::startMove(qreal dx,qreal dy)
{
    isMoving = true;
    speedX = dx;
    speedY = dy;
}

void Player::endMove()
{
    isMoving = false;
    speedX = 0;
    speedY = 0;
}

void Player::move()
{
    if(bindRect.left()+speedX < 0)
        bindRect.translate(-bindRect.left(),0);
    else if(bindRect.right()+speedX > 1000)
        bindRect.translate(1000-bindRect.right(),0);
    else
        bindRect.translate(speedX,0);
    if(bindRect.top()+speedY < 0)
        bindRect.translate(0,-bindRect.top());
    else if(bindRect.bottom()+speedY > 700)
        bindRect.translate(0,700-bindRect.bottom());
    else
        bindRect.translate(0,speedY);
    //static int cnt = 0;
    if(onePaceCount == 4)
    {
        onePaceCount = 0;
        paceCount++;
    }
    onePaceCount++;
}

/*void Player::attack()
{
    emit attackSignal(this);
}

void Player::skill()
{
    emit skillSignal(this);
}*/

void Player::draw(QPainter* painter)
{
    painter->save();
    //static int cnt = 0;
    paceCount = (paceCount == 4?0:paceCount);
    switch(faceDirection)
    {
    case 1:painter->drawPixmap(bindRect.topLeft(),pixmapListUp[paceCount]);break;
    case 2:painter->drawPixmap(bindRect.topLeft(),pixmapListDown[paceCount]);break;
    case 3:painter->drawPixmap(bindRect.topLeft(),pixmapListLeft[paceCount]);break;
    case 4:painter->drawPixmap(bindRect.topLeft(),pixmapListRight[paceCount]);break;
    default:break;
    }

    painter->restore();
}

void Player::logic()
{
    if(!enabled)
        return;
    if(isMoving)
        move();
    /*if(bindRect.intersects(enemyAttack->getBindRect()))
        emit attacked(3);
    if(bindRect.intersects(enemySkill->getBindRect()))
        emit skilled(8);*/
}
