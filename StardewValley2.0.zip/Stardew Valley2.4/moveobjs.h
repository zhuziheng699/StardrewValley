#ifndef MOVEOBJS_H
#define MOVEOBJS_H
#include<QObject>
#include<QPainter>
#include<QRectF>
#include<QPixmap>
#include<QVector>

class Moveobjs
{

public:
    Moveobjs();
    virtual ~Moveobjs(){}
    virtual void draw(QPainter*) = 0;
    virtual void logic() = 0;
    void setRect(QRectF);
    void setRect(qreal,qreal,qreal,qreal);
    QRectF& getBindRect();
    void addFrame(QPixmap);
    void clearAllFrame();
    void setEnabled(bool);
protected:
    QRectF bindRect;
    int frameCount;
    QVector<QPixmap> pixmapListUp;
    QVector<QPixmap> pixmapListDown;
    QVector<QPixmap> pixmapListLeft;
    QVector<QPixmap> pixmapListRight;
    //int pixmapListDirection;
    bool enabled;
signals:
public slots:
};

#endif // MOVEOBJS_H
